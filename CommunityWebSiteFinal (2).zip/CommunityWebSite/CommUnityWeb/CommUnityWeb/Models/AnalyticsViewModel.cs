﻿namespace CommUnityWeb.Models
{
    public class AnalyticsViewModel
    {
        public int AcceptedCount { get; set; }
        public int DeclinedCount { get; set; }
        public int PendingCount { get; set; }
        public string CollectionName { get; set; }
    }
}
